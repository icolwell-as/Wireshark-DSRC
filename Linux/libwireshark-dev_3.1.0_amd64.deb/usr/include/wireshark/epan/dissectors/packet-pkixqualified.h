/* Do not modify this file. Changes will be overwritten.                      */
/* Generated automatically by the ASN.1 to Wireshark dissector compiler       */
/* packet-pkixqualified.h                                                     */
/* asn2wrs.py -b -p pkixqualified -c ./pkixqualified.cnf -s ./packet-pkixqualified-template -D . -O ../.. PKIXqualified.asn */

/* Input file: packet-pkixqualified-template.h */

#line 1 "./asn1/pkixqualified/packet-pkixqualified-template.h"
/* packet-pkixqualified.h
 * Routines for RFC3739 PKIXqualified packet dissection
 *  Ronnie Sahlberg 2004
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PACKET_PKIXQUALIFIED_H
#define PACKET_PKIXQUALIFIED_H

/*#include "packet-pkixqualified-exp.h"*/

#endif  /* PACKET_PKIXQUALIFIED_H */

