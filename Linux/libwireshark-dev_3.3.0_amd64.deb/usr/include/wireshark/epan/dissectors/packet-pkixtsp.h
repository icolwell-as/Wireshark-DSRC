/* Do not modify this file. Changes will be overwritten.                      */
/* Generated automatically by the ASN.1 to Wireshark dissector compiler       */
/* packet-pkixtsp.h                                                           */
/* asn2wrs.py -b -p pkixtsp -c ./pkixtsp.cnf -s ./packet-pkixtsp-template -D . -O ../.. PKIXTSP.asn */

/* Input file: packet-pkixtsp-template.h */

#line 1 "./asn1/pkixtsp/packet-pkixtsp-template.h"
/* packet-pkixtsp.h
 * Routines for RFC3161 Time-Stamp Protocol packet dissection
 *    Ronnie Sahlberg 2004
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PACKET_PKIXTSP_H
#define PACKET_PKIXTSP_H

/*#include "packet-pkixtsp-exp.h"*/

#endif  /* PACKET_PKIXTSP_H */

