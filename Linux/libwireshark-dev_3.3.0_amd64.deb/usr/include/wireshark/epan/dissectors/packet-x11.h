/* packet-x11.h
 *
 * Put here so as to make packet-x11.c lighter. See packet-x11.c
 * This .h file should be included *only* in packet-x11.c
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

extern value_string_ext x11_keysym_vals_source_ext;
