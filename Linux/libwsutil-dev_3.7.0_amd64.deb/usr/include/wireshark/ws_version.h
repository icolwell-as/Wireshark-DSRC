/* ws_version.h.in */

#ifndef __WS_VERSION_H__
#define __WS_VERSION_H__

#define WIRESHARK_VERSION_MAJOR 3
#define WIRESHARK_VERSION_MINOR 7
#define WIRESHARK_VERSION_MICRO 0

#endif /* __WS_VERSION_H__ */
